package com.cg;

import java.util.Scanner;

public class CabUI  {
	static Scanner sc=new Scanner(System.in);
	static CabCollectionHelper collectionhelper=null; 
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice=0;
		collectionhelper=new CabCollectionHelper();
	
		
		while(true)
		{
			System.out.println("1:Add New cab\n"+
					"2:Find total count of cabs \n3:Exit");

			System.out.println("\nEnter UR Choice: ");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:	EnterNewCabDetails();break;
			case 2: collectionhelper.displayCabCount();break;
			default:System.exit(0);			
			}
		}
	}
	private static void EnterNewCabDetails() 
	{
		System.out.println("How many cabs ? ");
		
		int Ccount=sc.nextInt();
		
		while (Ccount!=0) {
		
		System.out.println("Enter cab otp:");
		String otp=sc.next();
		try 
		{
			if(CabDataValidator.validatecabId(otp))
			System.out.println("Enter pickUp:");
			String pickUp=sc.next();
			{
				System.out.println("Enter drop ");
				String drop =sc.next();
				if(CabDataValidator.validateDropName(drop))
				{
					System.out.println("Enter mobileNo ");
					String mobileNo =sc.next();
					if(CabDataValidator.validateMobileNumber1(mobileNo))
					{
						System.out.println("Enter cabType ");
						String cabType =sc.next();
						if(CabDataValidator.validateCabtype(cabType))
						{
					
						CabScema cab=new CabScema();
						collectionhelper.addNewCabDetails(cab);
				}	
					}
				}
			}
		}
					
		 
		catch (CabException e)
		{			
			System.out.println(e.getMessage());
		}
		Ccount--;
}
		
	}
}