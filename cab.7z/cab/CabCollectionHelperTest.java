package com.cg;

import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;



public class CabCollectionHelperTest  {
	static CabCollectionHelper collectionHelper;
	static CabScema cab=null;
	
	@BeforeClass
	public   static  void beforeClass()
	{
		collectionHelper=new CabCollectionHelper();
		cab =new CabScema();		
	}
	@AfterClass
	public static  void afterClass()
	{		
		collectionHelper=null;
		cab=null;
	}	
	
	
	@Test 
	public void testAddNewBook() throws CabException
	{
		collectionHelper.addNewCabDetails(cab);
		Assert.assertEquals(5, CabCollectionHelper.displayCabCount());
		//Assert.assertNotNull(collectionHelper.toString());
		
	}
}
