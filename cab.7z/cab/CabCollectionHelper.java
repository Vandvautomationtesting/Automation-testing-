package com.cg;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;


public class CabCollectionHelper {
	private  static ArrayList<CabScema> bookList=null;
	static
	{
		bookList=new ArrayList<CabScema>();
		//CabScema b1=new CabScema(123,"airoli","mumbai", 987654021, "mini");
		//CabScema b2=new CabScema(222,"sectornine","asdf", 345679450, "mega");
		//CabScema b3=new CabScema(333,"ckp","Airoli",345634356, "large");

		//bookList.add(b1);
		//bookList.add(b2);
		//bookList.add(b3);		

	}
public CabCollectionHelper(){}
	
	/*************Add New Book in ArrayList************/
	public void addNewCabDetails(CabScema cab) 
	{			
			
			bookList.add(cab);				
	}
	
	public static ArrayList<CabScema> getbookList() {
		return bookList;
	}

	public static void setbookList(ArrayList<CabScema> bookList) {
		CabCollectionHelper.bookList = bookList;
	}

	
	/*************Fetch All Book Details 
	 * @return ***********/

	public static  long displayCabCount()
	{
		Iterator<CabScema> bookIt=bookList.iterator();
		CabScema tempCab=null;
		
		int totalCount=0;
		while(bookIt.hasNext())
		{
			totalCount++;
			tempCab=bookIt.next();
			//System.out.println(tempBook);			
		}
		//System.out.println("Total Count of cab" + totalCount);
			System.out.println(totalCount);
			return totalCount;
	}

	
}
