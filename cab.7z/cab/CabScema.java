package com.cg;

public class CabScema {
	
	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public String getPickUp() {
		return pickUp;
	}

	public void setPickUp(String pickUp) {
		this.pickUp = pickUp;
	}

	public String getDrop() {
		return drop;
	}

	public void setDrop(String drop) {
		this.drop = drop;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getCabType() {
		return cabType;
	}

	public void setCabType(String cabType) {
		this.cabType = cabType;
	}

	private int otp;
	private String pickUp;
	private String drop;
	private int mobileNo;
	private String cabType;
	
	public CabScema() { }
	
	public CabScema(int otp, String pickUp, String drop, int mobileNo,String cabType) {
		this.otp = otp;
		this.pickUp = pickUp;
		this.drop = drop;
		this.mobileNo = mobileNo;
		this.cabType = cabType;
	}
}

	
	