package com.cg;

import java.util.regex.Pattern;



public class CabDataValidator{
	public  static  boolean validateDropName(String dropName)throws CabException
	{
		String custPattern="[A-Za-z]{6,20}";
		if(Pattern.matches(custPattern, dropName))
		{
			return true;
		}
		else
		{
			throw new CabException("drop location should start with CAPITAL & Min 6 and Max 20 characters Allowed");
		}
	}
	
	public  static  boolean validatecabId(String cabId)throws CabException
	{
		String IdPattern="\\d{4}";
		if(Pattern.matches(IdPattern, cabId))
		{
			return true;
		}
		else
		{
			throw new CabException("Only 4-digit CabId is Allowed");
		}
	}
	
	public  static  boolean validateMobileNumber1( String mobileNo)throws CabException
	{
		String numberPattern="[6789][0-9]{9}";
		
		if(Pattern.matches(numberPattern,mobileNo ))
		{
			return true;
		}
		else
		{
			throw new CabException("Only numbers are allowed and sholud contains 10 digits");
		}
	}
	public  static  boolean validateCabtype(String bookName)throws CabException
	{
		String custPattern="[A-Za-z]{4,20}";
		if(Pattern.matches(custPattern, bookName))
		{
			return true;
		}
		else
		{
			throw new CabException("cab type should start with CAPITAL & Min 4 and Max 20 characters Allowed");
		}
	}

	
	

	
}
