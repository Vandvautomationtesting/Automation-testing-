package com.cg.testclassmodule4;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

	public class TestClass {
		WebDriver driver;
		File src;
		FileInputStream fileFIS;
		 
		Document xmlDoc;
		
		String chromepath;
		String appURL;
		
		@BeforeTest
		public void setup() throws IOException, DocumentException{
			
			//To access xml file
			src=new File("./testNGmodule4.xml");
			fileFIS=new FileInputStream(src);
			
			SAXReader xmlReader=new SAXReader();
			xmlDoc=xmlReader.read(fileFIS);
			
			chromepath=xmlDoc.selectSingleNode("//OpenCart//ChromeDriver").getText();
			appURL=xmlDoc.selectSingleNode("//OpenCart//WebAppURL").getText();
			
			System.setProperty("webdriver.chrome.driver", chromepath);
			
			driver=new ChromeDriver();
			driver.get(appURL);;
			driver.manage().window().maximize();
		}
		@Test
		public void VerifyRegistration() {
			String account=xmlDoc.selectSingleNode("//OpenCart//MyAccount").getText();
			String register=xmlDoc.selectSingleNode("//OpenCart//Register").getText();
			driver.get(account);
			driver.get(register);;
			driver.findElement(By.name(xmlDoc.selectSingleNode("//OpenCart//FirstName").getText())).sendKeys("kavya");
			driver.findElement(By.name(xmlDoc.selectSingleNode("//OpenCart//LastName").getText())).sendKeys("killani");
			driver.findElement(By.name(xmlDoc.selectSingleNode("//OpenCart//Email").getText())).sendKeys("kavya456@gmail.com");
			driver.findElement(By.name(xmlDoc.selectSingleNode("//OpenCart//MobileNo").getText())).sendKeys("1234567890");
			driver.findElement(By.name(xmlDoc.selectSingleNode("//OpenCart//Password").getText())).sendKeys("kavya@34");
			driver.findElement(By.name(xmlDoc.selectSingleNode("//OpenCart//ConfirmPassword").getText())).sendKeys("kavya@34");
			driver.findElement(By.name(xmlDoc.selectSingleNode("//OpenCart//Subscribe").getText())).click();
			driver.findElement(By.name(xmlDoc.selectSingleNode("//OpenCart//CheckBox").getText())).click();
		    driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Continue").getText())).click();
			 
			 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Phones").getText())).click();
			 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//HTC").getText())).click();
			 driver.findElement(By.id(xmlDoc.selectSingleNode("//OpenCart//Cart").getText())).click();

			 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Brands").getText())).click();
			 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Click").getText())).click();

			 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//AddTOWishlist").getText())).click();
			 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//WishList").getText())).click();
		}
		@AfterTest
		public void CloseBrowser(){
			driver.quit();
		}
	}

	

	





