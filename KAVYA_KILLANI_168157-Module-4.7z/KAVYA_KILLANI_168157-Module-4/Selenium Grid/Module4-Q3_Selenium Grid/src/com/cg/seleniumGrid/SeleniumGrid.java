package com.cg.seleniumGrid;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class SeleniumGrid {
	
		public static void main(String[] args)throws MalformedURLException,InterruptedException{
			// TODO Auto-generated method stub
			WebDriver driver=new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"),DesiredCapabilities.chrome());
			//driver.get("http://demo.opencart.com/");
			
			
			String baseurl = "http://demo.opencart.com/";
			driver.get(baseurl);
			Thread.sleep(5000);
			String boText = driver.getTitle();
			//verifying the Title of the page
			if(boText.equals("Your Store")){
			System.out.println("Tilte Verified");
			}
			else{
			System.out.println("Title not verified");}
			
			//verify the no.of links
			List<WebElement> links=driver.findElements(By.tagName("a"));
			System.out.println(links.size());
			
			//Clicking on the MyAccount dropdown
			WebElement e=driver.findElement(By.className("dropdown"));
			e.click();
			//Selecting the Register option from dropdown
			driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
			Thread.sleep(2000);
			driver.manage().window().maximize();
			
			//Entering the FirstName
			WebElement searchBox=driver.findElement(By.xpath(".//*[@id='input-firstname']"));
			
			searchBox.sendKeys("qwertyuioplkjhg");
			
			//Entering the LastName
			WebElement searchBox1=driver.findElement(By.xpath(".//*[@id='input-lastname']"));
			
			searchBox1.sendKeys("qwertyuioplk");
			
			Thread.sleep(2000);
			
			//Entering the Email ID
			WebElement searchBox2=driver.findElement(By.xpath(".//*[@id='input-email']"));
			
			searchBox2.sendKeys("kavya4@gmail.com");
			
			//Entering the Telephone button
			WebElement searchBox3=driver.findElement(By.xpath(".//*[@id='input-telephone']"));
			
			searchBox3.sendKeys("776789");
			
			//Entering the Password
			WebElement searchBox4=driver.findElement(By.xpath(".//*[@id='input-password']"));
			
			searchBox4.sendKeys("killty34");
			
			//Entering the  Password in confirm password field
			WebElement searchBox5=driver.findElement(By.xpath(".//*[@id='input-confirm']"));
			
			searchBox5.sendKeys("killty34");
			
			//verifying subscribe radio button on page
			WebElement searchBox6=driver.findElement(By.xpath(".//*[@id='content']/form/fieldset[3]/div/div/label[2]"));
			
			searchBox6.click();
			
			//clicking on agree policy checkbox
			WebElement searchBox7=driver.findElement(By.name("agree"));
			
			searchBox7.click();
			
			//clicking on the continue button
			driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click();
			Thread.sleep(5000);
			System.out.println("The page title is: " + driver.getTitle());
		/*	//verifying the account has created title
			String baseurl1 = "https://demo.opencart.com/index.php?route=account/success";
			driver.get(baseurl1);
			Thread.sleep(5000);
			String boText1 = driver.getTitle();
			//verifying the Title of the page
			if(boText1.equals("Congratulations! Your new account has been successfully created!")){
			System.out.println("Account created Tilte Verified");
			}
			else{
			System.out.println("Account created Title not verified");}*/
			
			//clicking on 'phones & PDA's' option
			driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[6]/a")).click();
			Thread.sleep(5000);
			
			//clicking on /HTC TOUcH HD' icon
			driver.findElement(By.xpath(".//*[@id='content']/div[2]/div[1]/div/div[1]/a/img")).click();
			Thread.sleep(5000);
			
		/*	//verify text 'HTC Toch HD'
			driver.findElement(By.xpath(".//*[@id='content']/div[2]/div[1]/div/div[1]/a/img")).getText();*/
			
			//click on back button of a browser
			driver.navigate().back();
			
			//click on 'Add to cart' button for HTC Touch HD Mobile
			driver.findElement(By.xpath(".//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/button[1]")).click();
			Thread.sleep(5000);
			
			//verify the message 'success:you have added HTC Touch HD to your shopping cart!'
			System.out.println("The message is: " + driver.getTitle());
			
			//clicking on 'Brands' under 'Extras'
			driver.findElement(By.xpath("html/body/footer/div/div/div[3]/ul/li[1]/a")).click();
			Thread.sleep(5000);
			
			//verifying the title 'Find your favorite brand'
			System.out.println("The title is " + driver.getTitle());
			
			//clicking on C 'canon' option
			driver.findElement(By.xpath(".//*[@id='content']/div[2]/div/a")).click();
			Thread.sleep(5000);
			
			//verifying the heading as 'canon'
			System.out.println("The heading is: " + driver.getTitle());
			
			//click on add to wish list option'
			driver.findElement(By.xpath(".//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[2]")).click();
			Thread.sleep(5000);
			
			//verifying the message
			System.out.println("The message is: " + driver.getTitle());
			
			//click 'wish list' option under 'My accounts'
			driver.findElement(By.xpath("html/body/footer/div/div/div[4]/ul/li[3]/a")).click();
			Thread.sleep(5000);
			
			//verifying the title 'My wish list'
			System.out.println("Now The title is: " + driver.getTitle());
			
			//clicking on 'continue' button
			driver.findElement(By.xpath(".//*[@id='content']/div[2]/div/a")).click();
			Thread.sleep(5000);
			
			
			//validating the telephone number
			try{
			WebElement msg3=driver.findElement(By.xpath(".//*[@id='account']/div[5]/div/div"));
			String text3=msg3.getText();
			System.out.println("Warning Message is: "+text3);
			}catch(Exception Ex){
			System.out.println("Correct telephone");
		}
			
			
			driver.close();
	}
		}

	

