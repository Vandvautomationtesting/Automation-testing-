package com.cg.lab16;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ParatmeterizationWithExcel {
static String driverPath="C:\\Users\\kannaman\\Drivers\\chromedriver_win32\\";
	
	public static void main(String[] args)throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		File src=new File("C:\\Users\\kannaman\\workspace\\Module4Assignments\\UserDetails.xlsx");
		//using Java API specify workbook path
				FileInputStream fis = new FileInputStream(src);
				
				//to load entire workbook use XSSFWorkbook class
				XSSFWorkbook wb1 = new XSSFWorkbook(fis); //HSS used for .xls file
						
				//to get the access of sheet 1 use XSSFSheet class
				XSSFSheet sheet1 = wb1.getSheetAt(0);
						
				String FirstName=sheet1.getRow(1).getCell(0).getStringCellValue();
				String LastName=sheet1.getRow(1).getCell(1).getStringCellValue();
				String  EMail=sheet1.getRow(1).getCell(2).getStringCellValue();
				String password =sheet1.getRow(1).getCell(4).getStringCellValue();
				String ConfirmPassword=sheet1.getRow(1).getCell(5).getStringCellValue();
				
				System.out.println(FirstName);
				System.out.println(LastName);
				System.out.println(EMail);
				System.out.println(password);
				System.out.println(ConfirmPassword);
				
				System.setProperty("webdriver.chrome.driver",driverPath+"chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				
				driver.get("https://demo.opencart.com/");
				//Verify Title
				String verifyTitle=driver.getTitle();
				System.out.println("Page title is: "+verifyTitle);
				if(verifyTitle.equals("Your Store"))
					System.out.println("Expected title is present");
				else
					System.out.println("Expected title is not present");
				Thread.sleep(2000);
				
				//Click on "My Account "Main menu
				 WebElement searchBox=driver.findElement(By.className("dropdown"));
					searchBox.click();
					Thread.sleep(2000);
				//Select RegisterOption
					driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
					Thread.sleep(2000);
					
				driver.findElement(By.name("firstname")).sendKeys(FirstName);
				driver.findElement(By.name("lastname")).sendKeys(LastName);
				driver.findElement(By.name("email")).sendKeys(EMail);
				driver.findElement(By.name("password")).sendKeys(password);
				driver.findElement(By.name("confirm")).sendKeys(ConfirmPassword);
				driver.findElement(By.name("newsletter")).click();
				driver.findElement(By.name("agree")).click();
				driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click();
				
				driver.close();
						
				wb1.close();  

			}

}
