package com.cg.lab16;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ParameterizationWithDataProvider {
	 WebDriver driver;
	  
	 static String driverPath="C:\\Users\\kannaman\\Drivers\\chromedriver_win32\\";
	 @BeforeTest
	   public void setup(){
		   System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
			driver=new ChromeDriver();
			driver.get("https://demo.opencart.com/");
			driver.manage().window().maximize();
	   }
	 
	@DataProvider(name="UserDetails")
	public static Object[][] GetCredentials(){
		return new Object[][]{{"Annamani","kamma","Annamani@cg.com","cg@1234","cg@1234"},{"Devika","Devalla","Devika@97","dev@1234","dev@1234"}};
	}
	@Test(dataProvider="UserDetails")
	   public void LoginTest(String FirstName,String LastName,String EMail,String password,String ConfirmPassword) throws IOException, InterruptedException{
		//Verify Title
				String verifyTitle=driver.getTitle();
				System.out.println("Page title is: "+verifyTitle);
				if(verifyTitle.equals("Your Store"))
					System.out.println("Expected title is present");
				else
					System.out.println("Expected title is not present");
				Thread.sleep(2000);
				
				//Click on "My Account "Main menu
				 WebElement searchBox=driver.findElement(By.className("dropdown"));
					searchBox.click();
					Thread.sleep(2000);
				//Select RegisterOption
					driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
					Thread.sleep(2000);
		driver.findElement(By.name("firstname")).sendKeys(FirstName);
		driver.findElement(By.name("lastname")).sendKeys(LastName);
		driver.findElement(By.name("email")).sendKeys(EMail);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("confirm")).sendKeys(ConfirmPassword);
		driver.findElement(By.name("newsletter")).click();
		driver.findElement(By.name("agree")).click();
		driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click();
		   }
	 @AfterTest
		public void classBrowser(){
			driver.quit();
		}
}
