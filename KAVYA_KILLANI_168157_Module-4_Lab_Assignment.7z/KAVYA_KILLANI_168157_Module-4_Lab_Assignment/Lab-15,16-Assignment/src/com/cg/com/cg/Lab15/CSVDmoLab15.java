package com.cg.com.cg.Lab15;

import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import au.com.bytecode.opencsv.CSVReader;

public class CSVDmoLab15 {
  
	WebDriver driver;
	CSVReader reader;
	
	String CSV_PATH="C:\\Users\\abargode\\Desktop\\MPT 168124\\LAB15\\csvdemo.csv";
	static String driverPath = "C:\\Users\\abargode\\Desktop\\Training Material";
	
	@BeforeTest
	public void Setup(){
		System.setProperty("webdriver.chrome.driver", driverPath+"\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://demo.opencart.com/");
		driver.manage().window().maximize();
		String title = driver.getTitle();
		System.out.println(title);
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/a/span[1]")).click();
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
		String ARB = driver.findElement(By.xpath(".//*[@id='content']/h1")).getText();
		if(ARB.equals("Register Account")){
			System.out.println("You are on correct Page");
		}else{
			driver.close();
		}
	}
	
	@Test
	public void LoginTest() throws IOException, InterruptedException 
	{
		reader = new CSVReader(new FileReader(CSV_PATH));
		String [] csvCell;
		while((csvCell=reader.readNext())!= null)
		{
			String FirstName = csvCell[0];
			String LastName = csvCell[1];
			String Email = csvCell[2];
			String Telephone = csvCell[3];
			driver.findElement(By.id("input-firstname")).sendKeys(FirstName);
			Thread.sleep(1000);
			driver.findElement(By.id("input-lastname")).sendKeys(LastName);
			Thread.sleep(1000);
			driver.findElement(By.id("input-email")).sendKeys(Email);
			Thread.sleep(1000);
			driver.findElement(By.id("input-telephone")).sendKeys(Telephone);
			Thread.sleep(1000);
			driver.findElement(By.id("input-password")).sendKeys("123456");
			Thread.sleep(1000);
			driver.findElement(By.id("input-confirm")).sendKeys("123456");
			Thread.sleep(1000);
			driver.findElement(By.name("agree")).click();
			driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click();
			String BIGBOSS = driver.findElement(By.xpath(".//*[@id='account-register']/div[1]")).getText();
			System.out.println(BIGBOSS);
			driver.findElement(By.id("input-firstname")).clear();
			driver.findElement(By.id("input-lastname")).clear();
			driver.findElement(By.id("input-email")).clear();
			driver.findElement(By.id("input-telephone")).clear();
			driver.findElement(By.id("input-password")).clear();
			driver.findElement(By.id("input-confirm")).clear();
			driver.findElement(By.name("agree")).click();
		}
	}
	
	@AfterTest
	public void afterTest() throws IOException
	{
		driver.close();
		reader.close();
	}
}
