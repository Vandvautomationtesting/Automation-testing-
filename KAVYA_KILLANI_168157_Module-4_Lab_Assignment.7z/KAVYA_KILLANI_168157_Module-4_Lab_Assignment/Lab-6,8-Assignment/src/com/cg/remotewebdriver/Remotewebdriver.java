package com.cg.remotewebdriver;

	import java.net.MalformedURLException;
	import java.net.URL;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.remote.DesiredCapabilities;
	import org.openqa.selenium.remote.RemoteWebDriver;
	import org.openqa.selenium.support.ui.Select;

public class Remotewebdriver {
		 public static void main(String args[]) throws MalformedURLException, InterruptedException
		 {
			 WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), DesiredCapabilities.chrome());
			 driver.get("http://demo.opencart.com/");
			 driver.findElement(By.xpath(".//*[@id='logo']/h1/a"));
			 driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/a")).click();
			 driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/div/div/ul/li[2]/a")).click();
			 driver.findElement(By.id("content"));
			 Select drpSortBy= new Select(driver.findElement(By.id("input-sort")));
			 drpSortBy.selectByIndex(1);
			 driver.findElement(By.xpath(".//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[1]")).click();
	}
	}

