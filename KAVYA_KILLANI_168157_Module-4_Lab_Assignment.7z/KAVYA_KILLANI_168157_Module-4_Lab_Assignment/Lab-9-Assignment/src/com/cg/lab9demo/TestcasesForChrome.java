package com.cg.lab9demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TestcasesForChrome {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\nakkenap\\Desktop\\Training Material\\module-4\\Selenium Libraries\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://demo.opencart.com/");
		boolean title = driver.getTitle().contains("Your Store");
		if(title)
		{
			//String currentURL = driver.getCurrentUrl();
		    //If you want to verify a particular text is present or not on the page, do as below 
			//boolean b = driver.getPageSource().contains("your text");
			System.out.println(" Expected title is present");
		}
		 else if(!title) 
	   {
		System.out.println(" Expected title is not present"); 
		 }
		
		Thread.sleep(10000);
		
       driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/a")).click();
       driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/div/div/ul/li[2]/a")).click();
	   Thread.sleep(5000);
	   boolean title1 = driver.getTitle().contains("Mac");
		if(title1)
		{
			
			System.out.println(" Expected title Mac is present");
		}
		 else if(!title1) 
	   {
		System.out.println(" Expected title Mac is not present"); 
		 }
	   Select selectShow=new Select(driver.findElement(By.xpath(".//*[@id='input-sort']")));
	    selectShow.selectByIndex(1);
		Thread.sleep(5000);
	   driver.findElement(By.xpath(".//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[1]")).click();	
	   driver.findElement(By.name("search")).sendKeys("Mobile");
	   driver.findElement(By.xpath(".//*[@id='search']/span/button")).click();
	   Thread.sleep(10000);
	   driver.findElement(By.id("input-search")).clear();
	   Thread.sleep(10000);
	   driver.findElement(By.id("description")).click();
	   driver.findElement(By.id("button-search")).click();
	   driver.findElement(By.name("search")).sendKeys("Monitors");
	   Thread.sleep(10000);
	   driver.quit();
	}	 
}
