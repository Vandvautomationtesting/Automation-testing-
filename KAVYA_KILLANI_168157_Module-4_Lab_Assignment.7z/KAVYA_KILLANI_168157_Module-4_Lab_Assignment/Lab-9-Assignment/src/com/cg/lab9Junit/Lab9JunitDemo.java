package com.cg.lab9Junit;



import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;



public class Lab9JunitDemo {
WebDriver driver;
	
	@Before
	public  void openBrowser()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\nakkenap\\Desktop\\Training Material\\module-4\\Selenium Libraries\\chromedriver_win32\\chromedriver.exe");		
		driver = new ChromeDriver();
		
		driver.get("http://demo.opencart.com/");
	    driver.manage().window().maximize();
	}
   @Test
   public void testcase()
   {
	   String title=driver.getTitle();
	   Assert.assertEquals("Your Store", title);
   }
   @Test 
   public void testcase1()
   {
	   driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/a")).click();
       driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[1]/div/div/ul/li[2]/a")).click();
       String title1=driver.getTitle();
	   Assert.assertEquals("Mac", title1);
	   
   }
   @Test
	public void testCaseOne() throws InterruptedException
	{
		
		WebElement searchBox=driver.findElement(By.name("search"));
		
		searchBox.sendKeys("Phone");
		
		Thread.sleep(5000);
		
		driver.findElement(By.className("input-group-btn")).click();
						
		Thread.sleep(5000);
		
	}
   @After
   public  void closeBrowser()
	{
		driver.quit();
	}
}
