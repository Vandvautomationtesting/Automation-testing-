package com.cg.webdriverintro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Part22222 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\kikavya\\Desktop\\Selenium Libraries\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		driver.get("http://demo.opencart.com/index.php?route=account/register");
		
		driver.manage().window().maximize();
		
		
		WebElement searchBox=driver.findElement(By.xpath(".//*[@id='input-firstname']"));
		
		searchBox.sendKeys("qwertyuioplkjhg");
		
		
		WebElement searchBox1=driver.findElement(By.xpath(".//*[@id='input-lastname']"));
		
		searchBox1.sendKeys("qwertyuioplk");
		
		Thread.sleep(2000);
		
		WebElement searchBox2=driver.findElement(By.xpath(".//*[@id='input-email']"));
		
		searchBox2.sendKeys("kavyakilla3@gmail.com");
		
		WebElement searchBox3=driver.findElement(By.xpath(".//*[@id='input-telephone']"));
		
		searchBox3.sendKeys("776789");
		
		
		WebElement searchBox4=driver.findElement(By.xpath(".//*[@id='input-password']"));
		
		searchBox4.sendKeys("killty34");
		
		WebElement searchBox5=driver.findElement(By.xpath(".//*[@id='input-confirm']"));
		
		searchBox5.sendKeys("killty34");
		
		WebElement searchBox6=driver.findElement(By.className("radio-inline"));
		
		searchBox6.click();
		
		WebElement searchBox7=driver.findElement(By.name("agree"));
		
		searchBox7.click();
		
		driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath(".//*[@id='content']/div/div/a")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath(".//*[@id='content']/h2[2]"));
		Thread.sleep(5000);
		driver.findElement(By.xpath(".//*[@id='content']/ul[2]/li[1]/a")).click();
		Thread.sleep(5000);
		
		try{
			WebElement msg=driver.findElement(By.xpath(".//*[@id='account']/div[2]/div/div"));
			String text=msg.getText();
			System.out.println("Warning Message is: "+text);
		}catch(Exception Ex){
			System.out.println("Correct First Name");
		}
		
		Thread.sleep(5000);
		
		try{
			WebElement msg1=driver.findElement(By.xpath(".//*[@id='account']/div[3]/div/div"));
			String text1=msg1.getText();
			System.out.println("Warning Message is: "+text1);
		}catch(Exception Ex){
			System.out.println("Correct Last Name");
		}
		try{
			WebElement msg2=driver.findElement(By.xpath(".//*[@id='account']/div[4]/div/div"));
			String text2=msg2.getText();
			System.out.println("Warning Message is: "+text2);
		}catch(Exception Ex){
			System.out.println("correct phone number");
		}
		Thread.sleep(5000);
		try{
			WebElement msg3=driver.findElement(By.xpath(".//*[@id='account']/div[5]/div/div"));
			String text3=msg3.getText();
			System.out.println("Warning Message is: "+text3);
		}catch(Exception Ex){
			System.out.println("Correct telephone");
		}
		try{
			WebElement msg3=driver.findElement(By.xpath(".//*[@id='account']/div[6]/div/div"));
			String text3=msg3.getText();
			System.out.println("Warning Message is: "+text3);
		}catch(Exception Ex){
			System.out.println("Correct password");
		}
		
		Thread.sleep(10000);
		driver.quit();
		
	}

}

