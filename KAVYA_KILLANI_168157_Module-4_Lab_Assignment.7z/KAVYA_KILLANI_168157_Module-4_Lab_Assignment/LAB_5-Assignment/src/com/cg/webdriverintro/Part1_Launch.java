package com.cg.webdriverintro;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Part1_Launch {

		public static void main(String[] args) throws InterruptedException 
		{
			// TODO Auto-generated method stub
			System.out.println("Hello Selenium!!");
			
			System.setProperty("webdriver.chrome.driver","C:\\Users\\kikavya\\Desktop\\Selenium Libraries\\chromedriver_win32\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			
			driver.get("http://demo.opencart.com/");
			Thread.sleep(5000);
			
			System.out.println("The page title is: " + driver.getTitle());

		/*	Select myaccount=new Select(driver.findElement(By.("My Account")));
			
			myaccount.selectByIndex(2);
			
			Thread.sleep(5000);*/
			WebElement e=driver.findElement(By.className("dropdown"));
			e.click();
			driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
			//((Select) e).selectByValue("Register");
			
			Thread.sleep(5000);
			String baseurl = "https://demo.opencart.com/index.php?route=account/register";
			driver.get(baseurl);
			Thread.sleep(5000);
			String boText = driver.getTitle();
			if(boText.equals("Register Account")){
			System.out.println("Tilte Verified");
			}
			else{
			System.out.println("Title not verified");}
			driver.findElement(By.name("search")).sendKeys(Keys.PAGE_DOWN);
			
			//driver.findElement(By.partialLinkText("My Account")).click();
			//driver.findElement(By.partialLinkText("Register")).click();
			
			driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]"));
			driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath(".//*[@id='content']/form/div/div/a/b")).click();
		
			
			Thread.sleep(5000);
			
		
					
			driver.close();
			
		}	// TODO Auto-generated method stub

	}


