package com.cg.webdriverintro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Lab6validation {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\kikavya\\Desktop\\Selenium Libraries\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		driver.get("https://demo.opencart.com/index.php?route=account/login");
		
		driver.manage().window().maximize();
	//	WebElement searchBox=driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[2]/a"));
	//	searchBox.click();
		
		//giving email id
		
		WebElement searchBox1=driver.findElement(By.id("input-email"));
		
		searchBox1.sendKeys("kavyakillani24@gmail.com");
		//giving password
		
		WebElement searchBox2=driver.findElement(By.id("input-password"));
		
		searchBox2.sendKeys("killer1621");
		
		//login button is clicked
		
		driver.findElement(By.xpath(".//*[@id='content']/div/div[2]/div/form/input")).click();
		
		//components control
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[3]/a")).click();
		Thread.sleep(5000);
		//monitors click
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[3]/div/div/ul/li[2]/a")).click();
		Thread.sleep(5000);
		//show=25 control
	/*	WebElement searchBox8=driver.findElement(By.className("form-control"));
		searchBox8.click();
		Thread.sleep(5000);
		Select selectCountry=new Select(driver.findElement(By.id("input-limit")));
	
		selectCountry.selectByIndex(1);
		
		Thread.sleep(5000);
		
		selectCountry.selectByValue("25");*/
		driver.findElement(By.id("input-limit")).click();
		driver.findElement(By.xpath(".//*[@id='input-limit']/option[2]")).click();
		
		Thread.sleep(5000);
		//adding to cart
		driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
	
		Thread.sleep(5000);
		//specification
		WebElement searchBox9=driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[1]/ul[2]/li[2]/a"));
		searchBox9.click();
		//add to wishlist
		driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div[1]/button[1]")).click();
		//verify the success msg
		driver.findElement(By.xpath(".//*[@id='product-product']/div[1]")).click();
		//search the mobile in search button
		WebElement searchBox4=driver.findElement(By.xpath(".//*[@id='search']/input"));
		searchBox4.sendKeys("Mobile");
		//press the search button
		driver.findElement(By.xpath(".//*[@id='search']/span/button")).click();
		//product descriptions box 
		driver.findElement(By.xpath(".//*[@id='content']/p[1]/label")).click();
		//click on search
		driver.findElement(By.xpath(".//*[@id='button-search']")).click();
		
		//click on HTC HD box
		driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[1]/div/div[2]/div[1]/h4/a")).click();
		//clear 1 from the box quantity
		WebElement searchBox3=driver.findElement(By.xpath(".//*[@id='input-quantity']"));
		searchBox3.clear();
		
		//WebElement searchBox3=driver.findElement(By.xpath(".//*[@id='input-quantity']"));
		
		searchBox3.sendKeys("3");
		//adding to cart
		driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
		//success msg verification
		driver.findElement(By.xpath(".//*[@id='product-product']/div[1]")).click();
		//view cart option
		driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
		driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[1]/strong")).click();
		//verify the mobile 
		String str=driver.findElement(By.xpath(".//*[@id='content']/form/div/table/tbody/tr/td[2]/a")).getText();
		if(str.equals("HTC Touch HD")){
			System.out.println("mobile verified");
		}
		else{
			System.out.println("mobile not verified");
		}
		//click on checkout button
		driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[2]/a")).click();
		//click on account dropdown
		WebElement e=driver.findElement(By.className("dropdown"));
		e.click();
		Thread.sleep(5000);
		//logout button
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[5]/a")).click();
		String str2=driver.getTitle();
		if(str2.equals("Account Logout")){
			System.out.println("account logout verified");
		}
		else{
			System.out.println("account logout not verified");
		}
		Thread.sleep(10000);
		//continue button
		driver.findElement(By.xpath(".//*[@id='content']/div/div/a")).click();
		
		Thread.sleep(1000);
		driver.quit();
		
	}

}
