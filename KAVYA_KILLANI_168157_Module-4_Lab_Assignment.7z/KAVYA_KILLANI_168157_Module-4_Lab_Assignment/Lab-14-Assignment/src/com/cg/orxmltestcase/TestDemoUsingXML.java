package com.cg.orxmltestcase;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class TestDemoUsingXML{
	WebDriver driver;
	File src;
	FileInputStream fileFIS;
	Document xmlDoc;
	String chromepath;
	String appURL;
	 
	
	 @BeforeTest
	 public void Setup() throws IOException, DocumentException 
	 {
		 src=new File("./config.xml");
		 fileFIS=new FileInputStream(src);
		 SAXReader xmlReader=new SAXReader();
		 xmlDoc =xmlReader.read(fileFIS);
		 chromepath=xmlDoc.selectSingleNode("//OpenCart//ChromeDriver").getText();
		 appURL=xmlDoc.selectSingleNode("//OpenCart//WebAppURL").getText();
		 System.setProperty("webdriver.chrome.driver", chromepath);
		 driver=new ChromeDriver();
		 driver.get(appURL);
	 }
	 @Test
	 public void VerifyOpenCartDemo()
	 {
		 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Title").getText()));
			boolean title = driver.getTitle().contains("Your Store"); 
			if(title)
			{
				String currentURL = driver.getCurrentUrl();

			//If you want to verify a particular text is present or not on the page, do as below 
			boolean b = driver.getPageSource().contains("your text"); 
			System.out.println("Expected title is present ");
			}
					else if(!title) 
					{
					 System.out.println(" Expected title is not present");
					 }
		 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Desktops").getText())).click();
		 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Mac").getText())).click();
		 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Title1").getText()));
			boolean title1 = driver.getTitle().contains("Mac"); 
			if(title1)
			{
				String currentURL = driver.getCurrentUrl();

			//If you want to verify a particular text is present or not on the page, do as below 
			boolean b = driver.getPageSource().contains("your text"); 
			System.out.println("Expected title is present ");
			}
					else if(!title1) 
					{
					 System.out.println(" Expected title is not present");
					 }
		 Select sortby=new Select(driver.findElement(By.id(xmlDoc.selectSingleNode("//OpenCart//SortBy").getText())));
		 sortby.selectByIndex(1);
		 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//AddCart").getText())).click();
		 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//SearchIcon").getText())).click();
		 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Search1").getText())).click();
		 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Checkbox").getText())).click();
		 driver.findElement(By.xpath(xmlDoc.selectSingleNode("//OpenCart//Search2").getText())).click();
			
		 

	 }
	 @AfterTest
	 public void CloseBrowser()
	 {
		  driver.quit();
	 }
}


