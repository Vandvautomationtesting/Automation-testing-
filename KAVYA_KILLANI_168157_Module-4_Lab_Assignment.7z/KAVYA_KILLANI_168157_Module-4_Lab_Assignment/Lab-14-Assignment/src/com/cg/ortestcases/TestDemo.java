package com.cg.ortestcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestDemo  {
	WebDriver driver;
	File src;
	FileInputStream fileFIS;
	Properties propObj;
	String chromepath;
	String appURL;
	
	@BeforeTest
	public void setup() throws IOException{
		
		//To access propert file
		src=new File("./Configuration/config.property");
		fileFIS=new FileInputStream(src);
		
		//To read the property file create an object of properties class
		propObj=new Properties();
		
		//To load thge properties file
		propObj.load(fileFIS);
		chromepath=propObj.getProperty("ChromeDriver");
		appURL=propObj.getProperty("URL");
		System.setProperty("webdriver.chrome.driver", chromepath);
		driver=new ChromeDriver();
		driver.get(appURL);;
		driver.manage().window().maximize();
	}
	@Test
	public void VerifyTestOpenCart() {
		driver.findElement(By.xpath(propObj.getProperty("Title")));
		boolean title = driver.getTitle().contains("Your Store"); 
		if(title)
		{
			String currentURL = driver.getCurrentUrl();

		//If you want to verify a particular text is present or not on the page, do as below 
		boolean b = driver.getPageSource().contains("your text"); 
		System.out.println("Expected title is present ");
		}
				else if(!title) 
				{
				 System.out.println(" Expected title is not present");
				 }
		driver.findElement(By.xpath(propObj.getProperty("Desktops"))).click();
		driver.findElement(By.xpath(propObj.getProperty("Mac(1)"))).click();
		driver.findElement(By.xpath(propObj.getProperty("Title1")));
		boolean title1 = driver.getTitle().contains("Mac"); 
		if(title1)
		{
			String currentURL = driver.getCurrentUrl();

		//If you want to verify a particular text is present or not on the page, do as below 
		boolean b = driver.getPageSource().contains("your text"); 
		System.out.println("Expected title is present ");
		}
				else if(!title1) 
				{
				 System.out.println(" Expected title is not present");
				 }
		
		Select sortby=new Select(driver.findElement(By.id(propObj.getProperty("SortBy"))));
		sortby.selectByIndex(1);
		driver.findElement(By.xpath(propObj.getProperty("AddCart"))).click();
		driver.findElement(By.name(propObj.getProperty("Search"))).sendKeys("Mobile");
		driver.findElement(By.xpath(propObj.getProperty("SearchIcon"))).click();
		driver.findElement(By.xpath(propObj.getProperty("Search1"))).clear();
		driver.findElement(By.xpath(propObj.getProperty("Checkbox"))).click();
		driver.findElement(By.xpath(propObj.getProperty("Search2"))).click();
		
		
	}
	 @AfterTest
	 public void CloseBrowser()
	 {
		  driver.quit();
	 }
  }



