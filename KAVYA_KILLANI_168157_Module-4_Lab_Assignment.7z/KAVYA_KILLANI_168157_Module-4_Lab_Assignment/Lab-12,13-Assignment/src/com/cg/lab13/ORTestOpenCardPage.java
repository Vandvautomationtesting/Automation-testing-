package com.cg.lab13;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ORTestOpenCardPage {
	WebDriver driver;
	File src;
	FileInputStream fileFIS;
	Document xmlDoc;

	String chromePath;
	String appURL;

	@BeforeTest
	public void Setup() throws FileNotFoundException, DocumentException {
	src = new File("./config.xml");
	fileFIS = new FileInputStream(src);

	SAXReader xmlReader = new SAXReader();
	xmlDoc = xmlReader.read(fileFIS);

	chromePath = xmlDoc.selectSingleNode("//Website//ChromeDriver").getText();
	appURL = xmlDoc.selectSingleNode("//Website//WebAppURL").getText();

	System.setProperty("webdriver.chrome.driver", chromePath);
	driver = new ChromeDriver();

	driver.get(appURL);
	driver.manage().window().maximize();
	}
	@Test
	public void VerifyWebsite() throws InterruptedException
	{
	if(driver.getTitle().contains("Your Store")){
	System.out.println("Titile Match");
	}
	else{
	System.out.println("Title not match");
	}
	Thread.sleep(2000);
	driver.findElement(By.xpath(xmlDoc.selectSingleNode("//Website//Desktops").getText())).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath(xmlDoc.selectSingleNode("//Website//Mac").getText())).click();
	Thread.sleep(5000);
	Select drp = new Select(driver.findElement(By.xpath(xmlDoc.selectSingleNode("//Website//Sort_By").getText())));
	drp.selectByIndex(1);
	Thread.sleep(2000);
	driver.findElement(By.xpath(xmlDoc.selectSingleNode("//Website//Add_to_Cart").getText())).click();
	Thread.sleep(2000);
	driver.findElement(By.name(xmlDoc.selectSingleNode("//Website//Mobile").getText())).sendKeys("Mobile");
	Thread.sleep(2000);
	driver.findElement(By.xpath(xmlDoc.selectSingleNode("//Website//Search").getText())).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath(xmlDoc.selectSingleNode("//Website//Search_Criteria").getText())).clear();
	Thread.sleep(2000);
	driver.findElement(By.xpath(xmlDoc.selectSingleNode("//Website//product_descriptions").getText())).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath(xmlDoc.selectSingleNode("//Website//Button").getText())).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath(xmlDoc.selectSingleNode("//Website//Monitor").getText())).sendKeys("Monitors");
	Thread.sleep(2000);
	driver.findElement(By.xpath(xmlDoc.selectSingleNode("//Website//Search1").getText())).click();
	Thread.sleep(2000);
	System.out.println("Title Test Passed");

	}
	@AfterTest
	public void CloseBrowser()
	{
	driver.quit();
	}
}
